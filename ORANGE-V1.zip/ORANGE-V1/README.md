# ORANGE V1 — Android live chat

Native Android app built with Expo / React Native and Supabase. V1 includes email/password sign-up and sign-in, unique usernames, one-to-one conversations, persistent text messages, inbox, and realtime message delivery.

## Connected backend

This project is preconfigured for the ORANGE Supabase project in Mumbai (`ap-south-1`). The client uses the public publishable key only. No service-role key is included. Database tables and RLS policies exist; the auth profile trigger and direct-chat RPC migration have been applied.

## Build an APK

The repository includes `.github/workflows/android-apk.yml`. Put this project in a GitHub repository and push to `main`; GitHub Actions will install dependencies, generate the native Android project, build a release APK and publish it as a workflow artifact. The build includes `arm64-v8a` and `armeabi-v7a`.

For local development with Node.js 20+ and Android Studio:

```bash
npm install
npx expo prebuild --platform android
cd android
./gradlew assembleRelease
```

APK output: `android/app/build/outputs/apk/release/app-release.apk`.

## Notes

- Android minimum API is 23 (Android 6.0); React Native 0.81 requires this baseline.
- V1 is one-to-one text chat. No groups, media, voice/video calls, push notifications or end-to-end encryption are included.
- Supabase free tier has limits and is not unlimited or guaranteed forever.
- Configure email confirmation and production auth policies in Supabase before public release.
