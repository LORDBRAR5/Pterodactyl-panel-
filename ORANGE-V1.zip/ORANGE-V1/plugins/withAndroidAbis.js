const { withAppBuildGradle } = require('@expo/config-plugins');
module.exports = function withAndroidAbis(config) {
  return withAppBuildGradle(config, config => {
    const marker = 'ORANGE_ABI_FILTERS';
    if (!config.modResults.contents.includes(marker)) {
      config.modResults.contents = config.modResults.contents.replace(
        /defaultConfig\s*\{/,
        `defaultConfig {\n        // ${marker}\n        ndk { abiFilters "arm64-v8a", "armeabi-v7a" }`
      );
    }
    return config;
  });
};