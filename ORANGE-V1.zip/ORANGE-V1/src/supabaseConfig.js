// ORANGE Supabase public client configuration. Never put a service_role key in this file.
export const SUPABASE_URL = 'https://lqpcfifmgajgosrlcdsi.supabase.co';
export const SUPABASE_ANON_KEY = 'sb_publishable_KpYjKA3tPT0rn96sqFpcOA_Ttjp_iYC';
